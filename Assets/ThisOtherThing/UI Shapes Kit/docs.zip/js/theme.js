/*
Namespace for docs site
*/
var DocsTheme = {

  init: function() {
    this.initSidebar();
  },

  initSidebar: function() {
    //sidebar dropdown menu
    $('#sidebar .sub-menu > a').click(function () {
      var above = $(this).prev('.sub-menu');
      // Toggle current submenu
      var sub = $(this).next();
      if (sub.is(":visible")) {
        $('.menu-arrow', this).removeClass('rotate-down');
        sub.slideUp(200);
        $(sub).removeClass("open");
        $(this).prev('.sub-menu').removeClass('open');
      } else {
        $('.menu-arrow', this).addClass('rotate-down');
        sub.slideDown(200);
        $(sub).addClass("open");
        $(this).prev('.sub-menu').addClass('open');
      }
    });

    $('.toggle-nav').on('click', function(event) {
      // console.log('toggle nav clicked');
      $('#sidebar').addClass('show-sidebar');
      $('#sidebar .sidebar-nav').addClass('show-sidebar-nav');
    });
    $('#close-button').on('click', function(event) {
      // console.log('close menu clicked');
      $('#sidebar').removeClass('show-sidebar');
      $('#sidebar .sidebar-nav').removeClass('show-sidebar-nav');
    });
  },
};
